{
  "schemaVersion": "1.0.0",
  "verificationContext": {
    "status": "VERIFICATION_INITIALIZED",
    "requestMetadata": {
      "processingStarted": "2025-05-14T07:58:30.840Z",
      "requestTimestamp": "2025-05-14T07:58:30.840Z",
      "requestId": "3210957a-5b44-4f40-bd01-1f502c4fdd5e"
    },
    "previousVerificationId": "",
    "verificationAt": "2025-05-14T07:58:30.840Z",
    "referenceImageUrl": "s3://kootoro-dev-s3-reference-f6d3xl/processed/2025/05/06/23591_5560c9c9_reference_image.png",
    "layoutId": 23591,
    "layoutPrefix": "5560c9c9",
    "notificationEnabled": false,
    "checkingImageUrl": "s3://kootoro-dev-s3-checking-f6d3xl/AACZ 3.png",
    "turnTimestamps": {
      "initialized": "2025-05-14T07:58:30.840Z"
    },
    "verificationType": "LAYOUT_VS_CHECKING",
    "turnConfig": {
      "maxTurns": 2,
      "referenceImageTurn": 1,
      "checkingImageTurn": 2
    },
    "vendingMachineId": "VM-3245",
    "verificationId": "32704fc3-c4d0-4a9c-a57d-21b7be6f155a"
  }
}