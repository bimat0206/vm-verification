#!/bin/bash
set -e  # Exit immediately if a command fails

# Manually set the ECR repository URL if terraform output isn't working
# Replace this with your actual ECR repository URL from the AWS console
ECR_REPO="879654127886.dkr.ecr.us-east-1.amazonaws.com/kootoro-dev-ecr-process-turn1-response-f6d3xl"
FUNCTION_NAME="kootoro-dev-lambda-process-turn1-f6d3xl"
AWS_REGION="us-east-1"

echo "Using ECR repository: $ECR_REPO"
echo "Function name: $FUNCTION_NAME"

# Clean go cache to avoid stale dependencies
echo "Cleaning Go cache..."
go clean -cache -modcache

# Log in to ECR
echo "Logging in to ECR..."
aws ecr get-login-password --region "$AWS_REGION" | docker login --username AWS --password-stdin "$ECR_REPO"

# Build the image from the parent directory to include all necessary files
echo "Building Docker image..."
# Show what directory we're in before building
echo "Current directory: $(pwd)"
echo "Building from: $(cd ../.. && pwd)"
cd ../.. && docker build -t "$ECR_REPO:latest" -f workflow-function/ProcessTurn1Response/Dockerfile --no-cache .

# Push the image
echo "Pushing Docker image to ECR..."
docker push "$ECR_REPO:latest"

# Deploy to AWS Lambda (requires AWS CLI and proper IAM permissions)
echo "Deploying to AWS Lambda..."
aws lambda update-function-code \
        --function-name "$FUNCTION_NAME" \
        --image-uri "$ECR_REPO:latest" \
        --region "$AWS_REGION"

echo "Docker image built and pushed successfully to $ECR_REPO:latest"
echo "Lambda function $FUNCTION_NAME updated with the new image"

# Verify Lambda function
echo "Verifying Lambda function configuration..."
aws lambda get-function --function-name "$FUNCTION_NAME" --region "$AWS_REGION" --query 'Configuration.[FunctionName,LastModified,State]'
