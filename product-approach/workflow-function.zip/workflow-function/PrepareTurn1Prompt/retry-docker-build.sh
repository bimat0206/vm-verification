#!/bin/bash
set -e  # Exit immediately if a command fails

# Manually set the ECR repository URL if terraform output isn't working
# Replace this with your actual ECR repository URL from the AWS console
ECR_REPO="879654127886.dkr.ecr.us-east-1.amazonaws.com/kootoro-dev-ecr-prepare-turn1-prompt-f6d3xl"
FUNCTION_NAME="kootoro-dev-lambda-prepare-turn1-f6d3xl"
AWS_REGION="us-east-1"

echo "Using ECR repository: $ECR_REPO"

# Create a temporary build directory
BUILD_DIR=$(mktemp -d)
echo "Created temporary build directory: $BUILD_DIR"

# Copy the function code to the build directory
cp -r ./* "$BUILD_DIR/"

# Create shared directory structure in the build directory
mkdir -p "$BUILD_DIR/shared"

# Copy shared packages to the build directory
echo "Copying shared packages..."
cp -r ../shared/bedrock "$BUILD_DIR/shared/"
cp -r ../shared/errors "$BUILD_DIR/shared/"
cp -r ../shared/logger "$BUILD_DIR/shared/"
cp -r ../shared/schema "$BUILD_DIR/shared/"
cp -r ../shared/templateloader "$BUILD_DIR/shared/"

# Create a temporary go.work file for the build
cat > "$BUILD_DIR/go.work" << EOF
go 1.24.0

use (
    .
    ./shared/bedrock
    ./shared/errors
    ./shared/logger
    ./shared/schema
    ./shared/templateloader
)
EOF

# Update go.mod to use local paths instead of ../shared
sed -i '' 's|../shared/|./shared/|g' "$BUILD_DIR/go.mod"

echo "Created temporary go.work file and updated module paths"

# Log in to ECR
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin "$ECR_REPO"

# Build the image from the temporary directory
echo "Building Docker image..."
docker build -t "$ECR_REPO:latest" "$BUILD_DIR"

# Push the image
echo "Pushing Docker image to ECR..."
docker push "$ECR_REPO:latest"

# Deploy to AWS Lambda (requires AWS CLI and proper IAM permissions)
echo "Deploying to AWS Lambda..."
aws lambda update-function-code \
 		--function-name "$FUNCTION_NAME" \
 		--image-uri "$ECR_REPO:latest" \
 		--region "$AWS_REGION" > /dev/null 2>&1

# Clean up the temporary build directory
echo "Cleaning up temporary build directory..."
rm -rf "$BUILD_DIR"

echo "Docker image built and pushed successfully to $ECR_REPO:latest"
echo "Lambda function $FUNCTION_NAME updated successfully"
