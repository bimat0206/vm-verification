basic_usage.go: Simple store/retrieve operations with JSON and binary data
lambda_integration.go: How to integrate with AWS Lambda and Step Functions
envelope_operations.go: Working with envelopes, references, and validation
category_operations.go: Using categories, key generation, and standard filenames
error_handling.go: Error creation, checking, validation, and error lists
real_world_usage.go: A complete workflow simulation showing how multiple Lambda functions would use the package